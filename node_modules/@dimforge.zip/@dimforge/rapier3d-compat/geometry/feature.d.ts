export declare enum FeatureType {
    Vertex = 0,
    Edge = 1,
    Face = 2,
    Unknown = 3
}
