# @pmndrs/cannon-worker-api

Web worker API for [cannon-es](https://npmjs.com/package/cannon-es). Primarily used in [@react-three/cannon](https://npmjs.com/package/@react-three/cannon).
