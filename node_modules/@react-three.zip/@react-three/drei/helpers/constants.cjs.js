"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("three");const r=(()=>parseInt(e.REVISION.replace(/\D+/g,"")))();exports.version=r;
