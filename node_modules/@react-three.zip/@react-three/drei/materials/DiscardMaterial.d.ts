export declare const DiscardMaterial: typeof import("three").ShaderMaterial & {
    key: string;
};
