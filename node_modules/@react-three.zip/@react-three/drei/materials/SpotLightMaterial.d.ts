import * as THREE from 'three';
export declare class SpotLightMaterial extends THREE.ShaderMaterial {
    constructor();
}
