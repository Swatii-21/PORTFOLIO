import * as React from 'react';

const context = /* @__PURE__ */React.createContext(null);

export { context };
