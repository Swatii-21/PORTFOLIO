export declare function useCursor(hovered: boolean, onPointerOver?: string, onPointerOut?: string, container?: HTMLElement): void;
