import { coordinatesConfigResolver } from './coordinatesConfigResolver'

export const scrollConfigResolver = coordinatesConfigResolver
