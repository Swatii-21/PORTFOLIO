import { coordinatesConfigResolver } from './coordinatesConfigResolver'

export const wheelConfigResolver = coordinatesConfigResolver
