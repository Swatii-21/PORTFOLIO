// additional core exports

export { rubberbandIfOutOfBounds } from './utils/maths'
